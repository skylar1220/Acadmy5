package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SprintBootApplicationTests {

	@Test
	void contextLoads() {		
	}

}
